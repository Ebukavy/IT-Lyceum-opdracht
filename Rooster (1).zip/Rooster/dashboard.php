<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f8f9fa;
        }
        h1, h2 {
            text-align: center;
            color: #007bff;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        table th, table td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 12px;
        }
        table th {
            background-color: #f2f2f2;
        }
        .btn {
            text-decoration: none;
            padding: 8px 16px;
            background-color: #007bff;
            color: #fff;
            border-radius: 4px;
            text-align: center;
            display: inline-block;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .rooster-table {
            margin-bottom: 30px;
        }
        .edit-link {
            margin-top: 10px;
            display: block;
            text-align: right;
        }
    </style>
</head>
<body>
    <h1>Dashboard</h1>
    <form method="post" action="dashboard.php" style="text-align: center;">
        <button type="submit" name="generate" class="btn">Generate Rooster for Next Week</button>
    </form>

    <?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Nu kun je $pdo veilig gebruiken voor database operaties
$stmt = $pdo->prepare("SELECT * FROM roosters WHERE created_by = ? ORDER BY week_start DESC");
$stmt->execute([$user_id]);
$roosters = $stmt->fetchAll();
// Voer je query uit om $roosters op te halen
$stmt = $pdo->prepare("SELECT * FROM roosters WHERE created_by = ? ORDER BY week_start DESC");
$stmt->execute([$user_id]);
$roosters = $stmt->fetchAll();

// Controleer of $roosters niet leeg is voordat je het gebruikt
?>
<h2>Your Roosters</h2>
<?php if (!empty($roosters)): ?>
    <div class="table-responsive">
        <?php foreach ($roosters as $rooster): ?>
            <div class="edit-link">
                <a href="edit.rooster.php?id=<?php echo $rooster['id']; ?>" class="btn btn-info">Edit</a>
            </div>
            <h3 style="margin-top: 20px;">Week starting: <?php echo htmlspecialchars($rooster['week_start']); ?></h3>
            <table class="rooster-table">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Maandag</th>
                        <th>Dinsdag</th>
                        <th>Woensdag</th>
                        <th>Donderdag</th>
                        <th>Vrijdag</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $week_data = json_decode($rooster['data'], true);
                    $times = ["08:00 - 09:00", "09:00 - 10:00", "10:00 - 11:00", "11:00 - 12:00", "12:00 - 13:00", "13:00 - 14:00", "14:00 - 15:00", "15:00 - 16:00"];
                    foreach ($times as $time): ?>
                        <tr>
                            <td><?php echo $time; ?></td>
                            <td><?php echo htmlspecialchars($week_data['Maandag'][$time]); ?></td>
                            <td><?php echo htmlspecialchars($week_data['Dinsdag'][$time]); ?></td>
                            <td><?php echo htmlspecialchars($week_data['Woensdag'][$time]); ?></td>
                            <td><?php echo htmlspecialchars($week_data['Donderdag'][$time]); ?></td>
                            <td><?php echo htmlspecialchars($week_data['Vrijdag'][$time]); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <p style="text-align: center;">No roosters found.</p>
<?php endif; ?>
</body>
</html>
