<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$rooster_id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if rooster_data is set and is an array
    if (isset($_POST['rooster_data']) && is_array($_POST['rooster_data'])) {
        $data = $_POST['rooster_data'];
        $stmt = $pdo->prepare("UPDATE roosters SET data = ? WHERE id = ? AND created_by = ?");
        $stmt->execute([json_encode($data), $rooster_id, $user_id]);

        header("Location: dashboard.php");
        exit();
    } else {
        // Handle error if rooster_data is not set or is not an array
        echo "Error: Invalid rooster data submitted.";
        exit();
    }
}

$stmt = $pdo->prepare("SELECT * FROM roosters WHERE id = ? AND created_by = ?");
$stmt->execute([$rooster_id, $user_id]);
$rooster = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch as associative array

if (!$rooster) {
    header("Location: dashboard.php");
    exit();
}

$roosterdata = json_decode($rooster['data'], true);

// Check if $roosterdata is null or not an array
if (!$roosterdata || !is_array($roosterdata)) {
    // Handle error if $roosterdata is not valid
    echo "Error: Invalid rooster data fetched.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Rooster</title>
</head>
<body>
    <h1>Edit Rooster for week starting <?php echo htmlspecialchars($rooster['week_start']); ?></h1>
    <form method="post" action="edit.rooster.php?id=<?php echo $rooster_id; ?>">
        <?php foreach ($roosterdata as $day => $times): ?>
            <h3><?php echo htmlspecialchars($day); ?></h3>
            <?php foreach ($times as $time => $activity): ?>
                <label for="<?php echo $day . $time; ?>"><?php echo $time; ?></label>
                <input type="text" id="<?php echo $day . $time; ?>" name="rooster_data[<?php echo $day; ?>][<?php echo $time; ?>]" value="<?php echo htmlspecialchars($activity); ?>"><br>
            <?php endforeach; ?>
        <?php endforeach; ?>
        <button type="submit">Save Changes</button>
    </form>
    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
