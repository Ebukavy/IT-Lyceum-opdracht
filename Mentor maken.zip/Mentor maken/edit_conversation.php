<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $conversation_date = $_POST['conversation_date'];
    $subject = $_POST['subject'];
    $notes = $_POST['notes'];
    $action_points = $_POST['action_points'];

    $sql = "UPDATE conversations SET 
            conversation_date='$conversation_date', 
            subject='$subject', 
            notes='$notes', 
            action_points='$action_points' 
            WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Gesprek bijgewerkt!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    if (!isset($_GET['id'])) {
        die("ID niet gespecificeerd.");
    }
    $id = $_GET['id'];
    $sql = "SELECT * FROM conversations WHERE id='$id'";
    $result = $conn->query($sql);
    if (!$result) {
        die("Query mislukt: " . $conn->error);
    }
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gesprek Wijzigen</title>
</head>
<body>
    <h2>Gesprek Wijzigen</h2>
    <form method="post" action="edit_conversation.php">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <input type="hidden" name="student_id" value="<?php echo $_GET['student_id']; ?>">
        Datum: <input type="datetime-local" name="conversation_date" value="<?php echo $row['conversation_date']; ?>" required><br>
        Onderwerp: <input type="text" name="subject" value="<?php echo $row['subject']; ?>"><br>
        Notities: <textarea name="notes"><?php echo $row['notes']; ?></textarea><br>
        Actiepunten: <textarea name="action_points"><?php echo $row['action_points']; ?></textarea><br>
        <input type="submit" value="Wijzigen">
    </form>
    <a href="view_conversations.php?student_id=<?php echo $_GET['student_id']; ?>">Terug naar overzicht</a>
</body>
</html>
