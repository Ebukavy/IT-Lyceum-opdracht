<?php
include 'db.php';

if (!isset($_GET['student_id'])) {
    die("Student ID niet gespecificeerd.");
}

$student_id = $_GET['student_id'];
$sql = "SELECT * FROM conversations WHERE student_id='$student_id'";
$result = $conn->query($sql);

if (!$result) {
    die("Query mislukt: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gesprekken Inzien</title>
</head>
<body>
    <h2>Gesprekken Inzien voor Student ID: <?php echo $student_id; ?></h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Mentor ID</th>
            <th>Datum</th>
            <th>Onderwerp</th>
            <th>Notities</th>
            <th>Actiepunten</th>
            <th>Acties</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row["id"]. "</td>
                        <td>" . $row["mentor_id"]. "</td>
                        <td>" . $row["conversation_date"]. "</td>
                        <td>" . $row["subject"]. "</td>
                        <td>" . $row["notes"]. "</td>
                        <td>" . $row["action_points"]. "</td>
                        <td>
                            <a href='edit_conversation.php?id=" . $row["id"] . "&student_id=" . $student_id . "'>Wijzigen</a>
                            <a href='delete_conversation.php?id=" . $row["id"] . "&student_id=" . $student_id . "'>Verwijderen</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='7'>Geen gesprekken gevonden</td></tr>";
        }
        $conn->close();
        ?>
    </table>
</body>
</html>
