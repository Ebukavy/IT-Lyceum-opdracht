<?php
$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "mentor_system";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Verbinding mislukt: " . $conn->connect_error);
}
?>
