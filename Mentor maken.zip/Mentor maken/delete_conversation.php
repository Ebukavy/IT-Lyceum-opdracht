<?php
include 'db.php';

if (!isset($_GET['id']) || !isset($_GET['student_id'])) {
    die("ID of Student ID niet gespecificeerd.");
}

$id = $_GET['id'];
$student_id = $_GET['student_id'];
$sql = "DELETE FROM conversations WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
    echo "Gesprek verwijderd!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
<a href="view_conversations.php?student_id=<?php echo $student_id; ?>">Terug naar overzicht</a>
