<?php
include 'db.php'; // Je database connectiebestand

// Functie om XSS (Cross-Site Scripting) aanvallen te voorkomen
function sanitize($input) {
    global $conn;
    return htmlspecialchars(mysqli_real_escape_string($conn, trim($input)));
}

// Toevoegen, bekijken, wijzigen en verwijderen van gesprekken
$message = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Toevoegen van een nieuw gesprek
    if (isset($_POST['add_conversation'])) {
        $student_id = sanitize($_POST['student_id']);
        $mentor_id = sanitize($_POST['mentor_id']);
        $conversation_date = sanitize($_POST['conversation_date']);
        $subject = sanitize($_POST['subject']);
        $notes = sanitize($_POST['notes']);
        $action_points = sanitize($_POST['action_points']);

        $sql = "INSERT INTO conversations (student_id, mentor_id, conversation_date, subject, notes, action_points)
                VALUES ('$student_id', '$mentor_id', '$conversation_date', '$subject', '$notes', '$action_points')";

        if ($conn->query($sql) === TRUE) {
            $message = "Nieuw gesprek toegevoegd!";
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Wijzigen van een bestaand gesprek
    if (isset($_POST['edit_conversation'])) {
        $conversation_id = sanitize($_POST['conversation_id']);
        $subject = sanitize($_POST['subject']);
        $notes = sanitize($_POST['notes']);
        $action_points = sanitize($_POST['action_points']);

        $sql = "UPDATE conversations SET 
                subject = '$subject',
                notes = '$notes',
                action_points = '$action_points'
                WHERE id = '$conversation_id'";

        if ($conn->query($sql) === TRUE) {
            $message = "Gesprek bijgewerkt!";
        } else {
            $error = "Error updating record: " . $conn->error;
        }
    }
}

// Verwijderen van een gesprek
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $conversation_id = sanitize($_GET['id']);

    $sql = "DELETE FROM conversations WHERE id = '$conversation_id'";
    if ($conn->query($sql) === TRUE) {
        $message = "Gesprek verwijderd!";
    } else {
        $error = "Error deleting record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Gesprek Toevoegen, Bekijken, Wijzigen, Verwijderen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        h2 {
            margin-bottom: 10px;
        }
        form {
            margin-bottom: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            width: 400px;
        }
        form input[type=text], form textarea, form input[type=datetime-local] {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
        }
        form textarea {
            height: 100px;
        }
        form input[type=submit] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            cursor: pointer;
        }
        form input[type=submit]:hover {
            background-color: #45a049;
        }
        .message {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        .error {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .conversation {
            margin-bottom: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            width: 400px;
        }
        .conversation h3 {
            margin-bottom: 5px;
        }
        .conversation p {
            margin: 5px 0;
        }
        .conversation a {
            text-decoration: none;
            color: #007bff;
            margin-right: 10px;
        }
        .conversation a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <?php
    if (!empty($message)) {
        echo '<div class="message">' . $message . '</div>';
    }
    if (!empty($error)) {
        echo '<div class="error">' . $error . '</div>';
    }
    ?>

    <?php if (!(isset($_GET['action']) && ($_GET['action'] == 'view' || $_GET['action'] == 'edit') && isset($_GET['id']))) { ?>
    <h2>Gesprek Toevoegen</h2>
    <form method="post">
        Student ID: <input type="text" name="student_id" required><br>
        Mentor ID: <input type="text" name="mentor_id" required><br>
        Datum: <input type="datetime-local" name="conversation_date" required><br>
        Onderwerp: <input type="text" name="subject"><br>
        Notities: <textarea name="notes"></textarea><br>
        Actiepunten: <textarea name="action_points"></textarea><br>
        <input type="submit" name="add_conversation" value="Toevoegen">
    </form>
    <?php } ?>

<?php
if (isset($_GET['action']) && $_GET['action'] == 'view' && isset($_GET['id'])) {
    $conversation_id = sanitize($_GET['id']);
    $sql = "SELECT * FROM conversations WHERE id = '$conversation_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
?>
        <h2>Gesprek Bekijken</h2>
        <div class="conversation">
            <h3><?php echo isset($row['subject']) ? $row['subject'] : "Geen onderwerp beschikbaar"; ?></h3>
            <p><strong>Datum:</strong> <?php echo isset($row['conversation_date']) ? $row['conversation_date'] : "Geen datum beschikbaar"; ?></p>
            <p><strong>Notities:</strong><br><?php echo isset($row['notes']) ? nl2br($row['notes']) : "Geen notities beschikbaar"; ?></p>
            <p><strong>Actiepunten:</strong><br><?php echo isset($row['action_points']) ? nl2br($row['action_points']) : "Geen actiepunten beschikbaar"; ?></p>
            <a href="add_conversation.php">Terug</a>
        </div>
<?php
    } else {
        echo "Gesprek niet gevonden.";
    }
} elseif (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $conversation_id = sanitize($_GET['id']);
    $sql = "SELECT * FROM conversations WHERE id = '$conversation_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
?>
        <h2>Gesprek Wijzigen</h2>
        <form method="post">
            <input type="hidden" name="conversation_id" value="<?php echo $row['id']; ?>">
            Onderwerp: <input type="text" name="subject" value="<?php echo $row['subject']; ?>"><br>
            Notities: <textarea name="notes"><?php echo $row['notes']; ?></textarea><br>
            Actiepunten: <textarea name="action_points"><?php echo $row['action_points']; ?></textarea><br>
            <input type="submit" name="edit_conversation" value="Wijzigen">
        </form>
        <a href="index.php">Terug</a>
<?php
    } else {
        echo "Gesprek niet gevonden.";
    }
} else {
    // HTML- en PHP-code voor het bekijken van alle gesprekken
    $sql = "SELECT * FROM conversations ORDER BY conversation_date DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
?>
            <div class="conversation">
                <h3><?php echo isset($row['subject']) ? $row['subject'] : "Geen onderwerp beschikbaar"; ?></h3>
                <p><strong>Datum:</strong> <?php echo isset($row['conversation_date']) ? $row['conversation_date'] : "Geen datum beschikbaar"; ?></p>
                <p><strong>Notities:</strong><br><?php echo isset($row['notes']) ? nl2br($row['notes']) : "Geen notities beschikbaar"; ?></p>
                <p><strong>Actiepunten:</strong><br><?php echo isset($row['action_points']) ? nl2br($row['action_points']) : "Geen actiepunten beschikbaar"; ?></p>
                <a href="?action=view&id=<?php echo $row['id']; ?>">Bekijk</a>
                <a href="?action=edit&id=<?php echo $row['id']; ?>">Wijzig</a>
                <a href="?action=delete&id=<?php echo $row['id']; ?>" onclick="return confirm('Weet je zeker dat je dit gesprek wilt verwijderen?')">Verwijder</a>
            </div>
<?php
        }
    } else {
        echo "Geen gesprekken gevonden.";
    }
}

$conn->close();
?>
</body>
</html>
